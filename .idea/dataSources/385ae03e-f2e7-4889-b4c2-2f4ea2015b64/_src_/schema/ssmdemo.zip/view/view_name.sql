CREATE VIEW view_name AS
  SELECT
    `ssmdemo`.`admin`.`id`          AS `id`,
    `ssmdemo`.`admin`.`username`    AS `username`,
    `ssmdemo`.`admin`.`password`    AS `password`,
    `ssmdemo`.`admin`.`state`       AS `state`,
    `ssmdemo`.`admin`.`create_time` AS `create_time`,
    `ssmdemo`.`admin`.`acourse_id`  AS `acourse_id`
  FROM `ssmdemo`.`admin`;
